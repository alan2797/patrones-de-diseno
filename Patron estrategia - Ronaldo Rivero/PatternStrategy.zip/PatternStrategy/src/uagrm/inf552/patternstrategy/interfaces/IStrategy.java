package uagrm.inf552.patternstrategy.interfaces;

/**
 *
 * @author ronaldo
 */
public interface IStrategy {
    
    void analize();
    
}
