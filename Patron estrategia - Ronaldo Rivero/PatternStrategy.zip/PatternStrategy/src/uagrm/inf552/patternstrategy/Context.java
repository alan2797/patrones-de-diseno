package uagrm.inf552.patternstrategy;

import uagrm.inf552.patternstrategy.interfaces.IStrategy;

/**
 *
 * @author ronaldo
 */
public class Context {
    
    private IStrategy strategy;

    public Context(IStrategy strategy) {
        this.strategy = strategy;
    }
    
    public void run(){
        this.strategy.analize();
    }
            
}
