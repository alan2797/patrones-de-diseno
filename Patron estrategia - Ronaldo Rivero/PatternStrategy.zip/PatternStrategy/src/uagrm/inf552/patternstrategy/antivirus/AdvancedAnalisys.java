package uagrm.inf552.patternstrategy.antivirus;

import uagrm.inf552.patternstrategy.interfaces.IStrategy;

/**
 *
 * @author ronaldo
 */
public abstract class AdvancedAnalisys implements IStrategy{
    
    @Override
    public void analize() {
        init();
        analizeMemory();
        analizeKeyloggers();
        analizeRootKits();
        analizeZip();
        finish();
    }
    
    abstract void init();
    
    abstract void analizeMemory();
    
    abstract void analizeKeyloggers();
    
    abstract void analizeRootKits();
    
    abstract void analizeZip();
    
    abstract void finish();
}
