package uagrm.inf552.patternstrategy.antivirus;

/**
 *
 * @author ronaldo
 */
public class SimpleAntivirus extends SimpleAnalisys{

    @Override
    void init() {
        System.out.println("Antivirus Simple - Análisis simple iniciado");
    }

    @Override
    void analizeZip() {
        try {
            System.out.println("Analizando Zip ...");
            Thread.sleep(1000);
            System.out.println("Análisis Zip terminado");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    void finish() {
        System.out.println("Antivirus Simple - Análisis simple finalizado");
    }
    
    
}
