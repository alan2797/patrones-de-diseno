package uagrm.inf552.patternstrategy.antivirus;

import uagrm.inf552.patternstrategy.interfaces.IStrategy;

/**
 *
 * @author ronaldo
 */
public abstract class SimpleAnalisys implements IStrategy {
    
    @Override
    public void analize() {
        init();
        analizeZip();
        finish();
    }
    
    abstract void init();
    
    abstract void analizeZip();
    
    abstract void finish();
    
}
