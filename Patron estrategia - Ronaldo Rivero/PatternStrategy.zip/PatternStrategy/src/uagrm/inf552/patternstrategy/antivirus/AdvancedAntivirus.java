package uagrm.inf552.patternstrategy.antivirus;

/**
 *
 * @author ronaldo
 */
public class AdvancedAntivirus extends AdvancedAnalisys{

    @Override
    void init() {
        System.out.println("Antivirus Avanzado - Análisis avanzado iniciado");
    }

    @Override
    void analizeMemory() {
        try {
            System.out.println("Analizando Memoria RAM ...");
            Thread.sleep(1000);
            System.out.println("Análisis Memoria RAM terminado");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    void analizeKeyloggers() {
        try {
            System.out.println("Analizando Keyloggers ...");
            Thread.sleep(1000);
            System.out.println("Análisis Keyloggers terminado");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    void analizeRootKits() {
        try {
            System.out.println("Analizando RootKits ...");
            Thread.sleep(1000);
            System.out.println("Análisis RootKits terminado");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    void analizeZip() {
        try {
            System.out.println("Analizando Zip ...");
            Thread.sleep(1000);
            System.out.println("Análisis Zip terminado");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    void finish() {
        System.out.println("Antivirus Avanzado - Análisis avanzado finalizado");
    }
    
}
