package uagrm.inf552.patternstrategy;

import uagrm.inf552.patternstrategy.antivirus.AdvancedAntivirus;

/**
 *
 * @author ronaldo
 */
public class PatternStrategy {

    public static void main(String[] args) {
        Context context = new Context(new AdvancedAntivirus());
        context.run();
    }
    
}
