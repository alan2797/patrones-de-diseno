# Design_Patterns
Patrones de Diseño, Clases de Arquitectura de Software FICCT
