/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Composite.business_layer;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author Miguel_Angel
 */
public abstract class ProjectComponent {

    protected String name;
    protected Employee employee;
    protected TypeComponent typeComponent;
    protected int indentation;

    public ProjectComponent(String name, Employee employee, TypeComponent typeComponent) {
        super();
        this.name = name;
        this.employee = employee;
        this.typeComponent = typeComponent;
        this.indentation = 4;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public int getIndentation() {
        return indentation;
    }

    public void setIndentation(int indentation) {
        this.indentation = indentation;
    }

    public TypeComponent getTypeComponent() {
        return this.typeComponent;
    }

    public abstract int getCost();

    public abstract boolean add(String root, ProjectComponent component);

    public abstract boolean remove(ProjectComponent component);

    public abstract ProjectComponent get(int index);

    @Override
    public abstract String toString();

    public abstract DefaultMutableTreeNode getTree();

}
