/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Composite.business_layer;

/**
 *
 * @author Miguel_Angel
 */
public class Client {
    private final ProjectComponent component;

    public Client(ProjectComponent component) {
        this.component = component;
    }
    
    
}
