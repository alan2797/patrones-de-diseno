/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Composite.business_layer;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeCellRenderer;

/**
 *
 * @author Miguel_Angel
 */
public class JobComposite extends ProjectComponent {

    private final List<ProjectComponent> list;

    public JobComposite(String name, Employee employee, TypeComponent typeComponent) {
        super(name, employee, typeComponent);
        this.list = new ArrayList<>();
    }

    @Override
    public int getCost() {
        int cost = 0;
        for (ProjectComponent component : this.list) {
            cost += component.getCost();
        }
        return cost;
    }

    @Override
    public boolean add(String root, ProjectComponent component) {
        if (getName().equalsIgnoreCase(root)) {
            return list.add(component);
        } else {
            boolean sw = false;
            for (ProjectComponent projectComponent : list) {
                if (projectComponent instanceof JobComposite) {
                    sw = projectComponent.add(root, component);
                }
            }
            return sw;
        }
    }

    @Override
    public boolean remove(ProjectComponent component) {
        return this.list.remove(component);
    }

    @Override
    public ProjectComponent get(int index) {
        return this.list.get(index);
    }

    @Override
    public String toString() {
        String s = String.format("%" + String.valueOf(getIndentation()) + "s", "# ")
                + "  " + getName()
                + "  | " + employee.toString()
                + "  | " + getCost()
                + " : Composite\n";
        setIndentation(getIndentation() + 4);
        for (ProjectComponent component : this.list) {
            component.setIndentation(getIndentation());
            s += component.toString();
        }
        setIndentation(getIndentation() - 4);
        return s;
    }

    @Override
    public DefaultMutableTreeNode getTree() {
        return null;
    }

}
