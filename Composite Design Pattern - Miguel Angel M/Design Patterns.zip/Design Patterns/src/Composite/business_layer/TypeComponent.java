/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Composite.business_layer;

/**
 *
 * @author Miguel_Angel
 */
public enum TypeComponent {
    LEAF(0), COMPOSITE(1);
    private final int value;

    private TypeComponent(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public TypeComponent newInstance(int index) {
        for (TypeComponent type : TypeComponent.values()) {
            if (index == type.value) {
                return type;
            }
        }
        throw new IllegalArgumentException("Index not found");
    }

    public TypeComponent newInstance(String enumTypeMenu) {
        for (TypeComponent typeMenu : TypeComponent.values()) {
            if (enumTypeMenu.equalsIgnoreCase(typeMenu.name())) {
                System.out.println(typeMenu.name());
                return typeMenu;
            }
        }
        throw new IllegalArgumentException("Index not found");
    }

    @Override
    public String toString() {
        return (getValue() == 0) ? "LEAF" : "COMPOSITE";
    }

}
