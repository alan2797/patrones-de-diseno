/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Composite.business_layer;

/**
 *
 * @author Miguel_Angel
 */
public enum TypeEmployee {
    PROJECT_MANAGER(0),
    SOFTWARE_ENGINEER(1),
    COMPONENT_ENGINEER(2),
    TEST_ENGINEER(3),
    DEVELOPER(4),
    IT_MANAGER(5);

    private final int value;

    private TypeEmployee(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public TypeEmployee newInstance(int index) {
        for (TypeEmployee type : TypeEmployee.values()) {
            if (index == type.value) {
                return type;
            }
        }
        throw new IllegalArgumentException("Index not found");
    }

    public TypeEmployee newInstance(String enumTypeEmployee) {
        for (TypeEmployee typeEmployee : TypeEmployee.values()) {
            if (enumTypeEmployee.equalsIgnoreCase(typeEmployee.name())) {
                System.out.println(typeEmployee.name());
                return typeEmployee;
            }
        }
        throw new IllegalArgumentException("Index not found");
    }

    @Override
    public String toString() {
        return (getValue() == 0) ? "PROJECT_MANAGER"
                : (getValue() == 1) ? "SOFTWARE_ENGINEER"
                        : (getValue() == 2) ? "COMPONENT_ENGINEER"
                                : (getValue() == 3) ? "TEST_ENGINEER"
                                        : (getValue() == 4) ? "DEVELOPER" : "IT_MANAGER";
    }

}
