/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Composite.business_layer;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author Miguel_Angel
 */
public class TaskLeaf extends ProjectComponent {

    private final int requiredHours;

    public TaskLeaf(int requiredHours, String name, Employee employee, TypeComponent typeComponent) {
        super(name, employee, typeComponent);
        this.requiredHours = requiredHours;
    }

    @Override
    public int getCost() {
        return this.requiredHours * employee.getHourlyWage();
    }

    @Override
    public boolean add(String root, ProjectComponent component  ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean remove(ProjectComponent component) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ProjectComponent get(int index) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        String s = String.format("%" + String.valueOf(getIndentation()) + "s", "* ")
                + "  " + String.valueOf(this.requiredHours)
                + "  | " + getName()
                + "  | " + employee.toString()
                + "  | " + String.valueOf(getCost()) + " Leaf\n";
        return s;
    }

    @Override
    public DefaultMutableTreeNode getTree() {
        DefaultMutableTreeNode leaf = new DefaultMutableTreeNode(String.valueOf(this.requiredHours)
                + " | " + getName()
                + " | " + employee.toString()
                + " | " + String.valueOf(getCost()));
        return leaf;
    }

}
