/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Composite.testing;

import Composite.business_layer.Employee;
import Composite.business_layer.JobComposite;
import Composite.business_layer.ProjectComponent;
import Composite.business_layer.TaskLeaf;
import Composite.business_layer.TypeComponent;
import Composite.presentation_layer.MainForm;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author Miguel_Angel
 */
public class Testing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainForm form = new MainForm();
        try {

            JFrame.setDefaultLookAndFeelDecorated(true);
            JDialog.setDefaultLookAndFeelDecorated(true);
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            //            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
            //            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
            //            UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {
        }
        form.setLocationRelativeTo(null);
        form.setVisible(true);

//        ProjectComponent task0 = new TaskLeaf(12, "Diseño", new Employee("Miguel", 7), TypeComponent.LEAF);
//        ProjectComponent task1 = new TaskLeaf(10, "Analisis", new Employee("Angel", 8), TypeComponent.LEAF);
//        ProjectComponent task2 = new TaskLeaf(5, "Pruebas", new Employee("Eyver", 11), TypeComponent.LEAF);
//        ProjectComponent task3 = new TaskLeaf(24, "Implementacion", new Employee("Arturo", 9), TypeComponent.LEAF);
//
//        ProjectComponent job0 = new JobComposite("Proyecto", new Employee("Javier", 9), TypeComponent.COMPOSITE);
//        ProjectComponent job1 = new JobComposite("Requisitos 2", new Employee("Luiz", 10), TypeComponent.COMPOSITE);
//        ProjectComponent job2 = new JobComposite("Requisitos 3", new Employee("Luis", 5), TypeComponent.COMPOSITE);
//        ProjectComponent job3 = new JobComposite("Requisitos 4", new Employee("Soledad", 6), TypeComponent.COMPOSITE);
//
//        job1.add(job3);
//        job1.add(task0);
//        job1.add(task1);
//        job3.add(task3);
//        job0.add(job1);
//        job0.add(job2);
//        
//        String s = job0.toString();
//        System.out.println(s);

    }

}
